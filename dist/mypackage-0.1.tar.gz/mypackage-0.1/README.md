# mypackage
This library was created as an example of how to publish your own Python package.

## building this package from GitHub
'python setup.py sdist'

##installing this package from GitHub
'pip install git+https://github.com/datasaiyan/mypackage.git'
##updating this package from GitHub
'pip install git --upgrade +https://github.com/datasaiyan/mypackage.git'
